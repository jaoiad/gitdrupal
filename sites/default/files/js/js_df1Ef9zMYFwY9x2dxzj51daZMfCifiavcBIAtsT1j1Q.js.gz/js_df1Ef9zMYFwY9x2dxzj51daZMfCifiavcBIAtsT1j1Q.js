/**
 * @file
 * Javascript behaviors for HTML editor integration.
 */

(function ($, Drupal, drupalSettings) {

  'use strict';

  /**
   * Initialize HTML Editor.
   *
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.yamlFormHtmlEditor = {
    attach: function (context) {
      $(context).find('.js-form-type-yamlform-html-editor textarea').once('yamlform-html-editor').each(function () {
        var allowedContent = drupalSettings['yamlform']['html_editor']['allowedContent'];
        var $textarea = $(this);
        CKEDITOR.replace(this.id, {
          // Turn off external config and styles.
          customConfig: '',
          stylesSet: false,
          contentsCss: [],
          allowedContent: allowedContent,
          // Use <br> tags instead of <p> tags.
          enterMode: CKEDITOR.ENTER_BR,
          shiftEnterMode: CKEDITOR.ENTER_BR,
          // Set height, hide the status bar, and remove plugins.
          height: '100px',
          resize_enabled: false,
          removePlugins: 'elementspath,magicline',
          // Toolbar settings.
          format_tags: 'p;h2;h3;h4;h5;h6',
          toolbar: [
            { name: 'styles', items: ['Format', 'Font', 'FontSize' ] },
            { name: 'basicstyles', items: [ 'Bold', 'Italic', 'Subscript', 'Superscript' ] },
            { name: 'insert', items: [ 'SpecialChar' ] },
            { name: 'colors', items: [ 'TextColor', 'BGColor' ] },
            { name: 'paragraph', items: [ 'NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote'] },
            { name: 'links', items: [ 'Link', 'Unlink'] },
            { name: 'tools', items: [ 'Source', '-', 'Maximize' ] }
          ]
        }).on('change', function(evt) {
          // Save data onchange since AJAX dialogs don't execute form.onsubmit.
          $textarea.val(evt.editor.getData().trim());
        });
      })
    }
  };

})(jQuery, Drupal, drupalSettings);
;
/**
 * @file
 * Javascript behaviors for other elements.
 */

(function ($, Drupal) {

  "use strict";

  /**
   * Toggle other input (text) field.
   *
   * @param {boolean} show
   *   TRUE will display the text field. FALSE with hide and clear the text field.
   * @param {object} $element
   *   The input (text) field to be toggled.
   */
  function toggleOther(show, $element) {
    var $input = $element.find('input');
    if (show) {
      // Limit the other inputs width to the parent's container.
      $element.width($element.parent().width());
      // Display the element.
      $element.slideDown();
      // Focus and require the input.
      $input.focus().prop('required', true);
      // Restore the input's value.
      var value = $input.data('yamlform-value');
      if (value !== undefined) {
        $input.val(value);
        $input.get(0).setSelectionRange(0, 0);
      }
      // Refresh CodeMirror used as other element.
      $element.parent().find('.CodeMirror').each(function (index, $element) {
        $element.CodeMirror.refresh();
      });
    }
    else {
      $element.slideUp();
      // Save the input's value.
      $input.data('yamlform-value', $input.val());
      // Empty and un-required the input.
      $input.find('input').val('').prop('required', false);
    }
  }

  /**
   * Attach handlers to select other elements.
   *
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.yamlFormSelectOther = {
    attach: function (context) {
      $(context).find('.js-yamlform-select-other').once('yamlform-select-other').each(function () {
        var $element = $(this);

        var $select = $element.find('.form-type-select');
        var $otherOption = $element.find('option[value="_other_"]');
        var $input = $element.find('.js-yamlform-select-other-input');

        if ($otherOption.is(':selected')) {
          $input.show().find('input').prop('required', true);
        }

        $select.on('change', function () {
          toggleOther($otherOption.is(':selected'), $input);
        });
      });
    }
  };

  /**
   * Attach handlers to checkboxes other elements.
   *
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.yamlFormCheckboxesOther = {
    attach: function (context) {
      $(context).find('.js-yamlform-checkboxes-other').once('yamlform-checkboxes-other').each(function () {
        var $element = $(this);
        var $checkbox = $element.find('input[value="_other_"]');
        var $input = $element.find('.js-yamlform-checkboxes-other-input');

        if ($checkbox.is(':checked')) {
          $input.show().find('input').prop('required', true);
        }

        $checkbox.on('change', function () {
          toggleOther(this.checked, $input);
        });
      });
    }
  };

  /**
   * Attach handlers to radios other elements.
   *
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.yamlFormRadiosOther = {
    attach: function (context) {
      $(context).find('.js-yamlform-radios-other').once('yamlform-radios-other').each(function () {
        var $element = $(this);

        var $radios = $element.find('input[type="radio"]');
        var $input = $element.find('.js-yamlform-radios-other-input');

        if ($radios.filter(':checked').val() === '_other_') {
          $input.show().find('input').prop('required', true);
        }

        $radios.on('change', function () {
          toggleOther(($radios.filter(':checked').val() === '_other_'), $input);
        });
      });
    }
  };

  /**
   * Attach handlers to buttons other elements.
   *
   * @type {Drupal~behavior}
   */
  Drupal.behaviors.yamlFormButtonsOther = {
    attach: function (context) {
      $(context).find('.js-yamlform-buttons-other').once('yamlform-buttons-other').each(function () {
        var $element = $(this);

        var $buttons = $element.find('input[type="radio"]');
        var $input = $element.find('.js-yamlform-buttons-other-input');

        if ($buttons.filter(':checked').val() === '_other_') {
          $input.show().find('input').prop('required', true);
        }

        // Note: Initializing buttonset here so that we can set the onchange
        // event handler.
        // @see Drupal.behaviors.yamlFormButtons
        var $container = $(this).find('.form-radios');
        // Remove all div and classes around radios and labels.
        $container.html($container.find('input[type="radio"], label').removeClass());
        // Create buttonset and set onchange handler.
        $container.buttonset().change(function () {
          toggleOther(($(this).find(':radio:checked').val() === '_other_'), $input);
        });
      });
    }
  };

})(jQuery, Drupal);
;
